<?php

namespace ESN\HRBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ESNHRBundle extends Bundle
{
}
