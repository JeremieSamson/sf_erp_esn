<?php

namespace ESN\TreasuryBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ESNTreasuryBundle extends Bundle
{
}
