<?php

namespace ESN\DashboardBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ESNDashboardBundle extends Bundle
{
}
