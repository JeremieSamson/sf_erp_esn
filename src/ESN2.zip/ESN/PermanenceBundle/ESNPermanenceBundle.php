<?php

namespace ESN\PermanenceBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ESNPermanenceBundle extends Bundle
{
}
