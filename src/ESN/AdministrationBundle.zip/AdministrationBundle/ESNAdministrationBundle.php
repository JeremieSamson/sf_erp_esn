<?php

namespace ESN\AdministrationBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ESNAdministrationBundle extends Bundle
{
}
