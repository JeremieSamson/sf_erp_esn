<?php

namespace ESN\MembersBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ESNMembersBundle extends Bundle
{
}
