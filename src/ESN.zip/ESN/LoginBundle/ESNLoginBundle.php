<?php

namespace ESN\LoginBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ESNLoginBundle extends Bundle
{
}
